namespace MVCProject.Models
{
public class KullaniciModel
{
    public string KullaniciAdi { get; set; }
    public string Sifre { get; set; }
}
}