namespace MVCProject.Models
{
public class KitapModel{
public string KitapAdi { get; set; }
public string Yazar { get; set; }
}
}