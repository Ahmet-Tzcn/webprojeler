public class KitapModel
{
    public int kitapId { get; set; }
    public string kitapAd { get; set; }
    public string yayinevi { get; set; }
    public int sayfaSayisi { get; set; }
    public string kitapTuru { get; set; }
    public string kitapResimUrl { get; set; }
    public string Yazar { get; set; }
}